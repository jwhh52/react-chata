import React from 'react';
import './css.css';
class Re extends React.Component {
    constructor() {
        super();
        this.state = { u: null, s: null};
        this.go = this.go.bind(this);
    }
    go() {
        fetch("http://lihuoqin.com/test/reg.php",
            {
                method: 'post',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'name=' + this.state.u.value + '&pwd=' + this.state.s.value 

            }
        )
        .then(
            res =>res.json() //异步操作返回解流数据
          ).then(
            data=>alert(data.msg)//then接受解流过的数据
          ).catch(
            err => console.log(err) 
          )


    }
    render() {

        return (
            <div className="Re-app">
                <div className="Re-bigput">
                    <input  className="Re-put" type="text" placeholder="学号" ref={t => this.state.u = t}></input>
                    <input className="Re-put" type="text" placeholder="密码" ref={t => this.state.s = t}></input>
                    <button className="Re-but" onClick={this.go}>注册</button>
                </div>
            </div>
        );
    }
}
export default Re;