import React from 'react';
import './css.css';
class Login extends React.Component {
    constructor() {
        super();
        this.state = { u: null,aa: null,bb:null,b:null };
    }
    change = (e) =>{
        console.log(this.state.u)
        this.state.u=e.target.value
        localStorage.setItem("name",this.state.u)
        console.log(localStorage)
    }
    go = () => {
        fetch("http://lihuoqin.com/test/login.php",
            {
                method: 'post',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'name=' + this.state.u+
                '&pwd=' + this.state.aa.value
            }
        ).then(
            res =>res.json() 
          ).then(
            data=>{
                alert(data.msg);
               console.log(data);
               
           if(data.code==1){
            alert('登录成功')
           }
        }
           
          )
          
        
          
           console.log(localStorage)
    }
    render() {
        return (
            <div className="lo-app">
                <div className="lo-bigput">
                    <input className="lo-put" type="text" placeholder="学号" onChange={this.change}></input><br/>
                    <input className="lo-put" type="password" placeholder="密码"ref={a => this.state.aa = a}></input><br/>
                    <button className="lo-but" onClick={this.go}>登入</button>
                </div>
            </div>
        );
    }
}
export default Login;