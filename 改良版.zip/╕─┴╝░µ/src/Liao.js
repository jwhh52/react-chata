import React from 'react';
import './css.css';
class Liao extends React.Component {
    constructor() {
        super();
        this.state = { c:11, n:'vv', u: null,alltid: [] };
        this.go = this.go.bind(this);
    }
    componentDidMount() {
      
        setInterval(()=> this.ju(),1000);
    }
    ju(){
        fetch("https://lihuoqin.com/test/chatlist.php?tid="+11)
        .then(re => re.json())
        .then(arr => {
            this.setState({ alltid: arr })
        });
    }
    go() { 
        let b=localStorage.getItem("name")
        fetch("https://lihuoqin.com/test/chatadd.php",
            {
                method: 'post',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body:  'nickname='+ b  + '&tid=' + this.state.c +'&content=' + this.state.u.value 
               
            }
        )
        

    }
    render() {
        return (
            <div class='app'>
                <div class='con'>
                    <div class='xxl'>
                        {this.state.alltid.map(s =>  <div  class='xx'> <div class='na'>{s.nickname}:</div> &nbsp;<div class='nei'>{s.content}</div> </div> )}
                    </div>
                 </div>
                <div class='foot'>
			       <div class="search-box">
                  
				    <input class="input" type="search" ref={t => this.state.u = t} />
			    </div>
                <button class='butt' onClick={this.go} >发送</button>
		 </div>
        </div>
    );
        
    }
}
export default Liao;