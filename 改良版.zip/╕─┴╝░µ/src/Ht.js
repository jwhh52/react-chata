import React from 'react';
import './css.css';
class Ht extends React.Component {
    constructor() {
        super();
        this.state = {  u: null,m:'vv',t:null,alltid: [] };
        this.go = this.go.bind(this);
        this.sc = this.sc.bind(this);
    }
    componentDidMount() {
      
        setInterval(()=> this.ju(),1000);
    }
    ju(){
        fetch("https://lihuoqin.com/test/topiclist.php")
        .then(re => re.json())
        .then(arr => {
            this.setState({ alltid: arr })
        });
    }
    go() { 
        let b=localStorage.getItem("name")
        fetch("https://lihuoqin.com/test/topicadd.php",
            {
                method: 'post',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body:  'uname='+ b  + '&topic=' + this.state.u.value 
                
               
            }
        )
    }
    sc(){
        fetch("https://lihuoqin.com/test/topicdel.php",
            {
                method: 'post',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body:  'tid='+ this.state.t.value  ,
            }
        )
    
    }

    render() {
        return (
            <div class='app'>
                <div class='htl'>

                {this.state.alltid.map(s =>  <div class='neirong'>  &nbsp;<div class='conn'>{s.topic}</div><div class='zuozh'>发布者：{s.uname}</div> </div> )}
                </div>
                  <div class='foo'>
                   
                  
				<input class="input1" type="search" placeholder="话题" ref={t => this.state.u = t} />
                    
                <br></br>
                <br></br>
                <button class='butt1' onClick={this.go} >添加话题</button>
                </div>
        </div>
    );
        
    }
    
}

export default Ht;