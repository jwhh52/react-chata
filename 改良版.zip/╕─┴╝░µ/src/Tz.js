import React from 'react';
import './css.css';

import Login from "./Login";
import Re from "./Re";
import Liao from "./Liao";
import Ht from "./Ht";

import { Routes, Route, Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap'

class Tz extends React.Component {
  render() {
    return (
      <div className='body'>
     
        <div className='header'>
          
        </div>
        <div><div className='zd-button'>
              <button className='app-login'><Link to="/Login">登录</Link></button>
              <button className='app-re'><Link to="/Re">注册</Link></button>
          </div>

        </div>
        <div className='footer'>
        <button className='app-login'> <Link to="/Liao">聊天</Link>  </button> <Link to="/Ht">话题</Link>
        </div>
        <Routes>
          <Route path="/Login" element={<Login />} />
          <Route path="/Re" element={<Re />} />
          <Route path="/Liao" element={<Liao />} />
          <Route path="/Ht" element={<Ht />} />
        </Routes>
      </div>
    );

  }
}


export default Tz;
