import './App.css';
import Reg from "./reg";
import Login from "./Login";
import React from 'react';
import List from './List';
import Add from './add';
import { Routes, Route, Link } from "react-router-dom";

class App extends React.Component {
  
  render() {
    return (
      <div className='App-header'style={{color: 'write'}}>
       <Link style={{color: 'write'}} to="/Re">register</Link>    <Link  to="/Login">login</Link>  <Link  to="/List">list</Link>  <Link  to="/add">add</Link>
        <Routes>
          <Route path="/Re" element={<Reg />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/List" element={<List />} />
          <Route path="/add" element={<Add />} />
        </Routes>
      </div>
    );

  }
}
export default App;